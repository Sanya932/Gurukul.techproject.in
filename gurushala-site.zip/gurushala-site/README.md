# GuruShala — Static Website

This folder is production‑ready. Host on Netlify, Vercel, GitHub Pages, or any static server.

## Quick Deploy Options
- **Netlify:** Drag & drop the `/gurushala-site` folder into https://app.netlify.com/drop
- **Vercel:** `vercel .` in this folder (framework: "Other")
- **GitHub Pages:** Push to a repo, then enable Pages → root `/`

## Customize
- HTML: `index.html`
- CSS: `assets/styles.css`
- JS: `assets/script.js`
- Slides: `assets/images/slide_*.png`

No build step required.